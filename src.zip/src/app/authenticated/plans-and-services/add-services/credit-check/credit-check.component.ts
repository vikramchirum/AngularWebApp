import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mygexa-credit-check',
  templateUrl: './credit-check.component.html',
  styleUrls: ['./credit-check.component.scss']
})
export class CreditCheckComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
