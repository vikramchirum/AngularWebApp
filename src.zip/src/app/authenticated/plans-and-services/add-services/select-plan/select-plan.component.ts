import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mygexa-select-plan',
  templateUrl: './select-plan.component.html',
  styleUrls: ['./select-plan.component.scss']
})
export class SelectPlanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
