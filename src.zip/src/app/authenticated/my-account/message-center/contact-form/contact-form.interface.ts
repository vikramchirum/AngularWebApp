export interface Contact {
    phoneNumber:string;
    message:string;
}