import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mygexa-auto-pay-signup',
  templateUrl: './auto-pay-signup.component.html',
  styleUrls: ['./auto-pay-signup.component.scss']
})
export class AutoPaySignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
