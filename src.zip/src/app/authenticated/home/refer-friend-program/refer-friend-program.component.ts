import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mygexa-refer-friend-program',
  templateUrl: './refer-friend-program.component.html',
  styleUrls: ['./refer-friend-program.component.scss']
})
export class ReferFriendProgramComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
