export interface IToken {
  Code: string;
  Message: string;
  Data: string;
}
