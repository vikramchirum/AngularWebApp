
import { assign } from 'lodash';

export interface OfferRequest {
    startDate: string;
    dunsNumber: string;
}
