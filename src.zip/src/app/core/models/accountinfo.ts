/**
 * Created by vikram.chirumamilla on 7/21/2017.
 */

import {AccountType} from './enums/accounttype';

export interface IAccountInfo {
  Account_Type: AccountType;
  Account_Number: string;
}
