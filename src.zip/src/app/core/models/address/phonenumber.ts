/**
 * Created by vikram.chirumamilla on 7/21/2017.
 */

export interface IPhoneNumber {
  Type: string;
  Area_Code: string;
  Number: string;
  Extension: string;
  Agree_To_Marketing: string;
}
