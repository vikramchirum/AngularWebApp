/**
 * Created by vikram.chirumamilla on 7/10/2017.
 */

export class ICancelBudgetBillingRequest {

  Billing_Account_Id: number;
  User_Name: string;
}
