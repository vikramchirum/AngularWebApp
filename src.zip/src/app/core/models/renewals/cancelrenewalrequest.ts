/**
 * Created by vikram.chirumamilla on 7/10/2017.
 */

export interface ICancelRenewalRequest {
  billing_account_id: number;
  user_name: string;
}
