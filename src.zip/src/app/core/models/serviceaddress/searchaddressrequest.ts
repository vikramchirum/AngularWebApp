/**
 * Created by vikram.chirumamilla on 7/17/2017.
 */

export interface ISearchAddressRequest {
  partial: string;
}
