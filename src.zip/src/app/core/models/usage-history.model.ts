export interface UsageHistory {
    Billing_Account_Id: number;
    Usage_Month: string;
    Usage_Start_Date: string;
    Usage_End_Date: string;
    Usage_Type: string;
    Usage: string;
    Usage_Uom: string;
}
