/**
 * Created by vikram.chirumamilla on 7/21/2017.
 */

export enum NotificationStatus {
  Active,
  Suspended,
  Canceled
}
