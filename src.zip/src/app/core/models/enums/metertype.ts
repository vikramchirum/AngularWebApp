/**
 * Created by vikram.chirumamilla on 7/17/2017.
 */

export enum MeterType {
  Unknown,
  AMSM,
  AMSR,
  Scalar
}
