/**
 * Created by vikram.chirumamilla on 7/17/2017.
 */

export enum MeterStatus {
  Active,
  DeEnergized,
  Inactive,
  SwitchHold
}
