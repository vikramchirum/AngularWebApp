/**
 * Created by vikram.chirumamilla on 7/21/2017.
 */

export enum AccountType {
  GEMS_Billing_Account,
  GEMS_Residential_Customer_Account
}
