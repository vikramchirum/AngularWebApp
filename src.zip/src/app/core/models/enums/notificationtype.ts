/**
 * Created by vikram.chirumamilla on 7/21/2017.
 */

export enum NotificationType {
  Bill,
  Contract_Expiration,
  Payment_Due,
  Payment_Received
}
