export const environment = {
  Production: true,
  Name: 'Production',
  Api_Url: 'https://gexaapi.azure-api.net/prospecting-admin/api',
  Api_Token: '15c8ca95f0184b46ac3b6a6f4de8d472',
  Forte_Api_Key: 'GwnI15Vj36',
  Documents_Url: 'https://docs.gexaenergy.com/invoice/generate/',
  DollarAmountFormatter: '1.2-2'
};
